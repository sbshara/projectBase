# Google-This-Term-CKEditor
A simple CKEditor context menu plugin to add a menu button for searching selected text on the google.
